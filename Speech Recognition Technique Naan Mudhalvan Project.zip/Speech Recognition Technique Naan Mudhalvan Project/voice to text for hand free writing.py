import speech_recognition as sr

def listen_and_transcribe():
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    print("🎤 Speak now (press Ctrl+C to stop)...")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        while True:
            try:
                print("Listening...")
                audio = recognizer.listen(source)
                text = recognizer.recognize_google(audio)
                print("You said:", text)
                with open("transcribed_text.txt", "a") as f:
                    f.write(text + "\n")
            except sr.UnknownValueError:
                print("Sorry, I could not understand that.")
            except sr.RequestError as e:
                print(f"API error: {e}")
            except KeyboardInterrupt:
                print("\nStopped by user.")
                break

if __name__ == "__main__":
    listen_and_transcribe()
